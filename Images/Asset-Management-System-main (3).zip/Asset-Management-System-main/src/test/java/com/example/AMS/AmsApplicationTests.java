package com.example.AMS;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
