package com.example.AMS.repository;

public interface L_LogingRepository {
}
