package com.example.AMS.exception;

public class H_AssetException extends RuntimeException {
    public H_AssetException(String message) {
        super(message);
    }
}
