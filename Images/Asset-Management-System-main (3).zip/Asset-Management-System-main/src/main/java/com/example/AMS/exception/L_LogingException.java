package com.example.AMS.exception;

public class L_LogingException extends RuntimeException {
  public L_LogingException(String message) {
    super(message);
  }
}
