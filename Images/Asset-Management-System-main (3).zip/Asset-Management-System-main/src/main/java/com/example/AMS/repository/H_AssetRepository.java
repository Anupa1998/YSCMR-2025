package com.example.AMS.repository;

public interface H_AssetRepository {
}
